# Interview Questions – Answers

1. **What is REST?**
   Representational State Transfer – an architectural style where resources (e.g. books) are identified by URLs and manipulated using standard HTTP methods. It is stateless: each request carries all the info the server needs. Data is usually exchanged as JSON.

2. **What are HTTP methods and their use?**
   GET – read data. POST – create data. PUT – replace/update data (PATCH for partial update). DELETE – remove data.

3. **How do you handle routes in Express?**
   With `app.METHOD(path, handler)`, e.g. `app.get('/books', (req, res) => {...})`. Route parameters use `:id` and are read from `req.params`. `express.Router()` groups routes into modules.

4. **What is middleware in Express?**
   A function `(req, res, next)` that runs between the request and the final handler. It can modify `req`/`res`, end the request, or call `next()` to continue. Examples: `express.json()`, logging, authentication, error handlers.

5. **How do you parse JSON in Express?**
   `app.use(express.json());` – the parsed body is then available as `req.body`.

6. **What status codes do you use for CRUD?**
   200 OK (read/update/delete), 201 Created (POST), 204 No Content (delete without body), 400 Bad Request (invalid input), 404 Not Found, 500 Internal Server Error.

7. **How would you handle errors in Express?**
   Validate input and return 4xx codes in routes; use an error-handling middleware with four arguments `(err, req, res, next)` placed after all routes; use a catch-all 404 handler for unknown routes.

8. **What is CORS?**
   Cross-Origin Resource Sharing – a browser security mechanism that blocks web pages from calling APIs on a different origin unless the server allows it via headers like `Access-Control-Allow-Origin`. In Express: `npm install cors` then `app.use(cors())`.

9. **Explain request and response objects in Express.**
   `req` holds incoming data: `req.params` (URL params), `req.query` (query string), `req.body` (payload), `req.headers`. `res` is used to reply: `res.status(201)`, `res.json(data)`, `res.send()`, `res.sendStatus()`.

10. **How do you test API endpoints?**
    Manually with Postman or curl; automatically with Jest/Mocha + Supertest.
