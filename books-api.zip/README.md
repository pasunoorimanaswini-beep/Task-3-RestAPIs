# Task 3 – REST API for Managing Books (Node.js + Express)

A simple REST API with full CRUD operations on books. Data is stored **in memory** (no database), so it resets when the server restarts.

## Run it
```bash
npm install
npm start        # http://localhost:3000
```

## Endpoints
| Method | URL            | Description          | Success |
|--------|----------------|----------------------|---------|
| GET    | `/books`       | Get all books        | 200     |
| GET    | `/books/:id`   | Get one book (bonus) | 200     |
| POST   | `/books`       | Add a book           | 201     |
| PUT    | `/books/:id`   | Update a book by ID  | 200     |
| DELETE | `/books/:id`   | Delete a book by ID  | 200     |

Book shape: `{ "id": 1, "title": "Clean Code", "author": "Robert C. Martin" }`

Errors: `400` (missing fields / invalid JSON), `404` (book or route not found).

## Example
```bash
curl -X POST http://localhost:3000/books \
  -H "Content-Type: application/json" \
  -d '{"title":"Atomic Habits","author":"James Clear"}'
```

## Testing with Postman
Import `postman_collection.json` and run the requests in order.

## What I did
Initialized the project with `npm init`, installed Express, created a server on port 3000, stored books in an array, built the four CRUD routes with `express.json()` middleware, added validation and error handling, and tested every endpoint.

Interview prep answers: see `INTERVIEW_QUESTIONS.md`.
