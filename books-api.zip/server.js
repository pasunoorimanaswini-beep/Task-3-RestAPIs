const express = require('express');
const app = express();
const PORT = 3000;

// Middleware: parse JSON request bodies
app.use(express.json());

// In-memory store (no database)
let books = [
  { id: 1, title: 'The Pragmatic Programmer', author: 'Andrew Hunt' },
  { id: 2, title: 'Clean Code', author: 'Robert C. Martin' },
];
let nextId = 3;

// GET /books - return all books
app.get('/books', (req, res) => {
  res.status(200).json(books);
});

// GET /books/:id - return a single book (bonus)
app.get('/books/:id', (req, res) => {
  const book = books.find((b) => b.id === Number(req.params.id));
  if (!book) return res.status(404).json({ error: 'Book not found' });
  res.status(200).json(book);
});

// POST /books - add a new book from request body
app.post('/books', (req, res) => {
  const { title, author } = req.body || {};
  if (!title || !author) {
    return res.status(400).json({ error: 'title and author are required' });
  }
  const book = { id: nextId++, title, author };
  books.push(book);
  res.status(201).json(book);
});

// PUT /books/:id - update a book by ID
app.put('/books/:id', (req, res) => {
  const book = books.find((b) => b.id === Number(req.params.id));
  if (!book) return res.status(404).json({ error: 'Book not found' });

  const { title, author } = req.body || {};
  if (!title && !author) {
    return res.status(400).json({ error: 'Provide title and/or author to update' });
  }
  if (title) book.title = title;
  if (author) book.author = author;
  res.status(200).json(book);
});

// DELETE /books/:id - remove a book
app.delete('/books/:id', (req, res) => {
  const index = books.findIndex((b) => b.id === Number(req.params.id));
  if (index === -1) return res.status(404).json({ error: 'Book not found' });
  const [removed] = books.splice(index, 1);
  res.status(200).json({ message: 'Book deleted', book: removed });
});

// 404 handler for unknown routes
app.use((req, res) => {
  res.status(404).json({ error: 'Route not found' });
});

// Error-handling middleware (e.g. malformed JSON)
app.use((err, req, res, next) => {
  if (err.type === 'entity.parse.failed') {
    return res.status(400).json({ error: 'Invalid JSON' });
  }
  console.error(err);
  res.status(500).json({ error: 'Internal server error' });
});

app.listen(PORT, () => console.log(`Server running on http://localhost:${PORT}`));
